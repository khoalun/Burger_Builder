export const REQUEST_ERROR = Symbol("REQUEST_ERROR");

export const SINGLE_API = Symbol("SINGLE_API");
