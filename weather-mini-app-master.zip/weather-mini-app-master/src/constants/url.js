export default {
  API_URL: process.env.API_URL || "http://localhost:3000/api",
  WEB_URL: process.env.WEB_URL || "http://localhost:3001"
};
