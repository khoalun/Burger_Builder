export default process.env.NODE_ENV;
